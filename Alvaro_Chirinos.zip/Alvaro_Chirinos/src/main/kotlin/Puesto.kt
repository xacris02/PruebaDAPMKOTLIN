class Puesto(val numero: Int) {
    var estado: String = "Libre"
    var consolaAsignada: Consola? = null
    var motivoProceso: String = ""
    fun ocupar(consola: Consola) {
        this.consolaAsignada = consola
        this.estado = "EnJuego"
        this.motivoProceso = ""
    }
    fun liberar() {
        this.consolaAsignada = null
        this.estado = "Libre"
        this.motivoProceso = ""
    }
    fun ponerEnProceso(motivo: String) {
        this.estado = "EnProceso"
        this.motivoProceso = motivo
    }
}
