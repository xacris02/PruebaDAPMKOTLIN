import java.time.LocalDateTime

fun esCodigoValido(codigo: String): Boolean {
    val regex = Regex("^[A-Za-z]{2}\\d{2}[A-Za-z]{2}$")
    return regex.matches(codigo)
}

sealed class Consola(
    val codigo: String,
    val marcaModelo: String,
    val fechaIngreso: LocalDateTime,
    val tipoUsuario: String
) {
    abstract fun calcularCostoBase(minutos: Int): Double
    abstract val nombreTipo: String
}

class ConsolaClasica(codigo: String, marcaModelo: String, tipoUsuario: String) :
    Consola(codigo, marcaModelo, LocalDateTime.now(), tipoUsuario) {
    override val nombreTipo = "ConsolaClasica"

    override fun calcularCostoBase(minutos: Int): Double {
        val tarifaHora = 800.0
        var costo = (minutos / 60.0) * tarifaHora
        if (tipoUsuario.lowercase() == "socio") {
            costo *= 0.8
        }
        return costo
    }
}

class ConsolaModerna(codigo: String, marcaModelo: String, tipoUsuario: String) :
    Consola(codigo, marcaModelo, LocalDateTime.now(), tipoUsuario) {
    override val nombreTipo = "ConsolaModerna"

    override fun calcularCostoBase(minutos: Int): Double {
        if (minutos < 20) return 0.0
        val tarifaHora = 1500.0
        return (minutos / 60.0) * tarifaHora
    }
}

class ConsolaVR(
    codigo: String,
    marcaModelo: String,
    tipoUsuario: String,
    val accesoriosPremium: Boolean
) : Consola(codigo, marcaModelo, LocalDateTime.now(), tipoUsuario) {
    override val nombreTipo = "ConsolaVR"

    override fun calcularCostoBase(minutos: Int): Double {
        val tarifaHora = 3000.0
        var costo = (minutos / 60.0) * tarifaHora
        if (accesoriosPremium) {
            costo *= 1.3
        }
        return costo
    }
}

data class Ticket(
    val numeroTicket: Int,
    val tipo: String,
    val codigo: String,
    val minutosUso: Int,
    val montoPagado: Double
)
