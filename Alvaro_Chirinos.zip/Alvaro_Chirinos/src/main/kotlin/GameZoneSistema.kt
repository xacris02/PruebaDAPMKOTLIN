import kotlinx.coroutines.delay

class GameZoneSistema {
    private val capacidad = 10
    val puestos: List<Puesto> = (1..capacidad).map { Puesto(it) }
    private val historialTickets = mutableListOf<Ticket>()
    private val historialConsolas = mutableListOf<Consola>()

    var recaudacionTotal: Double = 0.0
    private val recaudacionPorTipo: MutableMap<String, Double> = mutableMapOf(
        "ConsolaClasica" to 0.0,
        "ConsolaModerna" to 0.0,
        "ConsolaVR" to 0.0
    )
    private var contadorTickets = 1

    fun puestosDisponibles(): Int {
        return puestos.count { it.estado == "Libre" }
    }

    suspend fun registrarEntrada(consola: Consola) {
        if (!esCodigoValido(consola.codigo)) {
            println("Error Código inválido ('${consola.codigo}'). Operación rechazada.")
            return
        }

        val puestoLibre = puestos.find { it.estado == "Libre" }
        if (puestoLibre == null) {
            println("Error Sistema lleno. No hay puestos libres.")
            return
        }

        puestoLibre.ponerEnProceso("Registrando entrada de consola ${consola.codigo}")
        println("Puesto ${puestoLibre.numero}: ${puestoLibre.motivoProceso}...")

        puestoLibre.ocupar(consola)
        historialConsolas.add(consola)
        println("Éxito Puesto ${puestoLibre.numero} ahora está EN JUEGO con la consola ${consola.codigo}.")
    }

    suspend fun registrarSalida(codigoConsola: String, minutosUso: Int) {
        val puesto = puestos.find { it.consolaAsignada?.codigo == codigoConsola }
        if (puesto == null || puesto.consolaAsignada == null) {
            println("Error Consola código '$codigoConsola' no encontrada. El sistema continúa operando.")
            return
        }

        val consola = puesto.consolaAsignada!!

        puesto.ponerEnProceso("Calculando tarifa para consola $codigoConsola")
        println("Puesto ${puesto.numero}: ${puesto.motivoProceso}...")

        val costoBase = consola.calcularCostoBase(minutosUso)
        val costoConIva = costoBase * 1.19
        var montoFinal = costoConIva

        if (consola.tipoUsuario.lowercase() == "educacional") {
            montoFinal *= 0.5
        }

        if (montoFinal < 0.0 || (montoFinal == 0.0 && minutosUso > 0 && consola.nombreTipo != "ConsolaModerna")) {
            println("Error Tarifa inválida ($montoFinal). Se notificó pero el sistema sigue funcionando.")
            puesto.liberar()
            return
        }

        val ticket = Ticket(contadorTickets++, consola.nombreTipo, consola.codigo, minutosUso, montoFinal)
        historialTickets.add(ticket)
        recaudacionTotal += montoFinal
        recaudacionPorTipo[consola.nombreTipo] = (recaudacionPorTipo[consola.nombreTipo] ?: 0.0) + montoFinal

        puesto.liberar()
        println("Ticket #${ticket.numeroTicket} | Consola: ${ticket.codigo} | ${ticket.minutosUso} min | Pagado: \$${ticket.montoPagado}")
    }

    fun consultarSociosEnHistorial(): List<Consola> {
        return historialConsolas.filter { it.tipoUsuario.lowercase() == "socio" }
    }

    fun ingresoPromedioPorConsola(): Double {
        if (historialTickets.isEmpty()) return 0.0
        return recaudacionTotal / historialTickets.size
    }

    fun codigosConsolasFinalizadas(): List<String> {
        return historialTickets.map { it.codigo }
    }

    fun generarReporteCierre() {
        println("\nREPORTE DE CIERRE DE TURNO")
        historialTickets.forEach {
            println("- Ticket #${it.numeroTicket} | Tipo: ${it.tipo} | Código: ${it.codigo} | Uso: ${it.minutosUso} min | Total: \$${it.montoPagado}")
        }
        println("Total recaudado: \$$recaudacionTotal")
        println("Consolas finalizadas: ${historialTickets.size}")
        println("Ingreso promedio: \$${ingresoPromedioPorConsola()}")
        val tipoTop = recaudacionPorTipo.maxByOrNull { it.value }?.key ?: "Ninguno"
        println("Consola con más ingresos: $tipoTop")
        println("Puestos disponibles: ${puestosDisponibles()}")
    }
}
