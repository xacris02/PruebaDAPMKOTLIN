import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    val sistema = GameZoneSistema()
    println("INICIANDO SISTEMA GAMEZONE\n")

    val consolaInvalida = ConsolaClasica("123ABC", "PS4", "infantil")
    sistema.registrarEntrada(consolaInvalida)

    println("\nRegistrando Entradas")
    val c1 = ConsolaClasica("CC12CD", "PlayStation 5", "socio")
    val c2 = ConsolaClasica("CC99ZA", "Xbox Series X", "infantil")
    val c3 = ConsolaModerna("CM22TO", "Nintendo Switch", "infantil")
    val c4 = ConsolaVR("VR44RG", "Meta Quest 3", "educacional", true)
    val c5 = ConsolaVR("VR77RG", "HTC Vive Pro", "infantil", false)

    sistema.registrarEntrada(c1)
    sistema.registrarEntrada(c2)
    sistema.registrarEntrada(c3)
    sistema.registrarEntrada(c4)
    sistema.registrarEntrada(c5)

    println("\n Procesando Salidas ")
    sistema.registrarSalida("CC12CD", 75)
    sistema.registrarSalida("CC99ZA", 180)
    sistema.registrarSalida("CM22TO", 18)
    sistema.registrarSalida("VR44RG", 120)
    sistema.registrarSalida("VR77RG", 45)

    println("\nConsultas de Negocio")
    println("Socios que visitaron: ${sistema.consultarSociosEnHistorial().map { it.codigo }}")

    sistema.generarReporteCierre()
}
